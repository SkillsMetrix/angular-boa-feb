import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class GuardService implements CanActivate {
  isAllowed = false;
  canActivate() {
    if (!this.isAllowed) {
      alert('Unauthorized Access...!');
    } else {
      this.isAllowed = true;
    }

    return this.isAllowed;
  }
}
