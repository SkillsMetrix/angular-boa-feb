import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { GuardService } from './guard.service';

@Injectable({
  providedIn: 'root'
})
export class FormService {

  private apiURL='http://localhost:3000/users'

  constructor(private http:HttpClient) { }

  addUserToDB(data:any){
   this.http.post(this.apiURL,data).subscribe(data =>{
    console.log("user added");
    
   })
    
  }
  loginValidate(data:any){
   
    return this.http.get<any[]>(
      `${this.apiURL}?uname=${data.uname}&pass=${data.pass}`

    )
  }
  loadUsers(){
    return this.http.get(this.apiURL) 
  }
  deleteUser(id:string){
    return this.http.delete(`${this.apiURL}/${id}`)
  }
}
