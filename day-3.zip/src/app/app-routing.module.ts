import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { ReactiveComponent } from './components/reactive/reactive.component';
import { UserdataComponent } from './components/userdata/userdata.component';
import { PortfolioComponent } from './components/portfolio/portfolio.component';
import { UserComponent } from './components/user/user.component';
import { CompanyComponent } from './components/company/company.component';
import { GuardService } from './shared/guard.service';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: ReactiveComponent },
  { path: 'userdetails', component: UserdataComponent },
  {
    path: 'portfolio',
    component: PortfolioComponent, canActivate:[GuardService],
    children: [
      { path: 'user', component: UserComponent },
      { path: 'company', component: CompanyComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
