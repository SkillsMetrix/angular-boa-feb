import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { TemplateComponent } from './components/template/template.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { MaterialModule } from './material/material.module';
import { ReactiveComponent } from './components/reactive/reactive.component';
import { LoginComponent } from './components/login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { UserdataComponent } from './components/userdata/userdata.component';
import { LandingpageComponent } from './components/landingpage/landingpage.component';
import { PortfolioComponent } from './components/portfolio/portfolio.component';
import { NavigationComponent } from './components/navigation/navigation.component';
import { UserComponent } from './components/user/user.component';
import { CompanyComponent } from './components/company/company.component';
import { GuardService } from './shared/guard.service';
 

@NgModule({
  declarations: [
    AppComponent,
    TemplateComponent,
    ReactiveComponent,
    LoginComponent,
    UserdataComponent,
    LandingpageComponent,
    PortfolioComponent,
    NavigationComponent,
    UserComponent,
    CompanyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, FormsModule, MaterialModule,ReactiveFormsModule,HttpClientModule
],
  providers: [
    provideAnimationsAsync() 
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
