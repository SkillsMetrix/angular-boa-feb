import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormService } from '../../shared/form.service';

@Component({
  selector: 'app-template',
  templateUrl: './template.component.html',
  styleUrl: './template.component.css'
})
export class TemplateComponent {

  constructor(private fs:FormService){}

  cities=['pune','hyd','delhi','chennai','mumbai']

  register(nf:NgForm){
   
    this.fs.addUserToDB(nf.value)
  }

}
