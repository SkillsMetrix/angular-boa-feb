import { Component } from '@angular/core';
import { FormService } from '../../shared/form.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrl: './reactive.component.css',
})
export class ReactiveComponent {
  rf: FormGroup;
  constructor(
    private fs: FormService,
    private fb: FormBuilder,
    private router:Router
  ) {
    this.rf = this.fb.group({
      uname: ['',[Validators.required,Validators.minLength(4)]],
      pass: [''],
      email: ['',this.emailDomainValidator],
      city: [''],
    });
  }
  get f() {
    return this.rf.controls;
  }

  cities = ['pune', 'hyd', 'delhi', 'chennai', 'mumbai'];
  register() {
    this.fs.addUserToDB(this.rf.value)
    this.router.navigateByUrl('/login')
  }

  emailDomainValidator(control:FormControl){
    let email=control.value
    if(email && email.indexOf('@') !=-1){
      let[before,domain]= email.split('@')
      if(domain !=='boa.com'){
        return {
          ed:{
            pd: domain
          }
        }
      }
    }
    return null
  }
}
