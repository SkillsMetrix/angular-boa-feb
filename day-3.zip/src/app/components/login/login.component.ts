import { Component } from '@angular/core';
import { FormService } from '../../shared/form.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { GuardService } from '../../shared/guard.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  rf: FormGroup;
  constructor(
    private fs: FormService,
    private fb: FormBuilder,
    private route:Router,
    private gs:GuardService
  ) {
    this.rf = this.fb.group({
      uname: ['', [Validators.required]],
      pass: [''],
    });
  }
  get f() {
    return this.rf.controls;
  }

  login() {
    this.fs.loginValidate(this.rf.value).subscribe((users) =>{
      if(users.length > 0 && users[0].uname=='admin'){
        this.gs.isAllowed=true
        localStorage.setItem('user',JSON.stringify(users[0]))
        this.route.navigateByUrl('/userdetails')
      }else{
        alert('Unauthorized Access')
      }
    })
  }
}
