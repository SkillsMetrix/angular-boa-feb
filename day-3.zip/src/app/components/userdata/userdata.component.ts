import { Component, OnInit } from '@angular/core';
import { FormService } from '../../shared/form.service';
import { MatButtonModule } from "@angular/material/button";
import { MaterialModule } from "../../material/material.module";

@Component({
  selector: 'app-userdata',
  templateUrl: './userdata.component.html',
  styleUrl: './userdata.component.css',
 
 
})
export class UserdataComponent implements OnInit {
  constructor(private us: FormService) {}

  displayedColumns:string[]=['id','uname','email','city','action']
  users: any[] = [];
  ngOnInit(): void {
    this.loadData();
  }
  loadData() {
    this.us.loadUsers().subscribe((data: any) => {
      this.users = data;
    });
  }
  deleteUser(id:string){
    if(confirm('Are you sure to Delete this User?')){
      this.us.deleteUser(id).subscribe(()=>{
        this.loadData()
      })
    }

  }
}
