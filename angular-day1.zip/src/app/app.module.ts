import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainappComponent } from './components/mainapp/mainapp.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { UserDataService } from './shared/services/userdata.service';
import { FormsModule } from '@angular/forms';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import {MatButtonModule} from '@angular/material/button';

@NgModule({
  // it contains all components
  declarations: [
    AppComponent,
    MainappComponent,
    HeaderComponent,
    FooterComponent
  ],
  // conatins all modules
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,MatButtonModule
  ],
  //it contains all services
  providers: [UserDataService, provideAnimationsAsync()],
  // welcome component
  bootstrap: [AppComponent]
})
export class AppModule { }
