import { Component, Input } from '@angular/core';
import { UserDataService } from '../../shared/services/userdata.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css',
})
export class FooterComponent {
  constructor(private ud:UserDataService){
    this.people= this.ud.loadPeople()
  }
  @Input()
  myCity = 'pune';
  
  myProfile =
    'https://media.sproutsocial.com/uploads/2022/06/profile-picture.jpeg';

  addUser() {
    alert('user activated');
  }

  getColor(country: string) {
    switch (country) {
      case 'India':
        return 'blue';

      case 'USA':
        return 'green';

      case 'UK':
        return 'purple';
      default:
        return null;
    }
  }
  people:any[]=[]
}
