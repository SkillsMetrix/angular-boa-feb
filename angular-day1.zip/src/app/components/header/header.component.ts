import { Component } from '@angular/core';
import { UserDataService } from '../../shared/services/userdata.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent {
  constructor(private us: UserDataService) {
    this.userDetails = this.us.loadUsers();
  }

  userDetails;

  appUsers = [
    { name: 'Aman', active: true },
    { name: 'John', active: true },
    { name: 'Sandeep', active: false },
  ];
}
