import { Injectable } from '@angular/core';

@Injectable()
export class UserDataService {
  loadUsers(): string[] {
    return ['admin', 'manager', 'qa'];
  }

  loadPeople(): any[] {
    return [
      {
        name: 'Duglus',
        country: 'UK',
      },
      {
        name: 'Sam',
        country: 'USA',
      },
      {
        name: 'Smita',
        country: 'India',
      },
    ];
  }
}
