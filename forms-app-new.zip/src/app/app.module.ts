import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { TemplateComponent } from './components/template/template.component';
import { FormsModule } from '@angular/forms'
import { MaterialModule } from './material/material.module';
import { MatCard, MatCardHeader, MatCardTitle, MatCardContent } from "@angular/material/card";

@NgModule({
  declarations: [
    AppComponent,
    TemplateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, FormsModule, MaterialModule,
    MatCard,
    MatCardHeader,
    MatCardTitle,
    MatCardContent
],
  providers: [
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
