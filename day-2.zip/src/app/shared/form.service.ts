import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FormService {

  constructor(private http:HttpClient) { }

  addUserToDB(data:any){
   this.http.post('http://localhost:3000/users',data).subscribe(data =>{
    console.log("user added");
    
   })
    
  }
  loginValidate(data:any){
     console.log(data);
  }
}
