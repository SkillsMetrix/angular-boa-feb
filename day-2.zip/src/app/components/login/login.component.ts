import { Component } from '@angular/core';
import { FormService } from '../../shared/form.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  rf: FormGroup;
  constructor(
    private fs: FormService,
    private fb: FormBuilder,
  ) {
    this.rf = this.fb.group({
      uname: ['', [Validators.required]],
      pass: [''],
    });
  }
  get f() {
    return this.rf.controls;
  }

  login() {
    this.fs.loginValidate(this.rf.value);
  }
}
